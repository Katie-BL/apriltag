#!/usr/bin/env python3

import rospy
import sys
import select
import termios
import tty

from std_msgs.msg import String  # Replace with the actual message type if different

def key_listener():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        [i,_,_] = select.select([sys.stdin],[],[],0.1)
        if i:
            return sys.stdin.read(1)
        return None
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

def callback(data):
    rospy.loginfo(f"I heard: {data.data}\r\n")

def listener():
    # Initialize the node
    rospy.init_node('apriltag_listener', anonymous=True)

    # Subscribe to the topic
    rospy.Subscriber('/apriltag_detections', String, callback)

    rospy.loginfo("Press q to quit...")

    while not rospy.is_shutdown():
        key = key_listener()
        if key == 'q':
            rospy.loginfo("Quiting the program...")
            break

    rospy.loginfo("Shutting Down node...")

if __name__ == '__main__':
    listener()
