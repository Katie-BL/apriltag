#!/usr/bin/env python3

import cv2
import numpy as np
import rospy
from apriltag import Detector
from std_msgs.msg import String  # Message type to publish detection info

# Initialize the ROS node
rospy.init_node('apriltag_detector', anonymous=True)

# Create a publisher to send detection information
detection_pub = rospy.Publisher('/apriltag_detections', String, queue_size=10)

# Initialize the camera
camera = cv2.VideoCapture(0)

if not camera.isOpened():
    rospy.logerr("Error: Cannot open camera")
    exit()

# Initialize the AprilTag detector
detector = Detector()

while not rospy.is_shutdown():
    ret, frame = camera.read()

    # If no frame is captured, exit the loop
    if not ret:
        rospy.logerr("Error: Failed to grab frame")
        break

    # Convert the frame to grayscale for AprilTag detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect AprilTags
    detections = detector.detect(gray)

    # If any detections are found, publish to ROS topic
    if detections:
        for detection in detections:
            # Create a message containing detection information
            detection_msg = f"Tag ID: {detection.tag_id}, Center: {detection.center}"
            rospy.loginfo(detection_msg)  # Log the detection info
            detection_pub.publish(detection_msg)  # Publish the detection message

    # Display the live feed
    cv2.imshow("Live Feed", frame)

    # Wait for key press (exit on 'q')
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break

# Release the camera and close the OpenCV window
camera.release()
cv2.destroyAllWindows()
