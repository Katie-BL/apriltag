#!/usr/bin/env python3
#import rospy

#if __name__=='__main__'
#rospy.init_node("test_node")


import cv2
import numpy as np

#import apriltag
from apriltag import Detector

camera = cv2.VideoCapture(0)

if not camera.isOpened():
    print("Error Can not open Camera")
    exit()


detector = Detector()


while True:
    ret, frame = camera.read()




    key = cv2.waitKey(1) & 0xFF

    cv2.imshow("Live Feed", frame)

    cv2.imwrite("captured_image.jpg",frame)
    #print("Photo Saved")

    imagepath = 'captured_image.jpg'
    image = cv2.imread(imagepath, cv2.IMREAD_GRAYSCALE)
    #cv2.imshow('test', image)
    #cv2.waitKey(1000)
    
    detections = detector.detect(image)
    if detections:
        print(detections)
        exit()
        


    if key == ord('q'):
        break

camera.release()
cv2.destroyAllWindows()
