#!/usr/bin/env python3
#import rospy

#if __name__=='__main__'
#rospy.init_node("test_node")


import cv2
import numpy as np
#import apriltag
from apriltag import Detector

imagepath = '/home/kat/Documents/apriltag/test/data/33369213973_9d9bb4cc96_c.jpg'
image = cv2.imread(imagepath, cv2.IMREAD_GRAYSCALE)
cv2.imshow('test', image)
cv2.waitKey(1000)
#detector = Detector("tagStandard41h12")
detector = Detector()

detections = detector.detect(image, True)
print(detections)
