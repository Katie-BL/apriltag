import cv2
import numpy as np
import rospy

#import apriltag
from apriltag import Detector

camera = cv2.VideoCapture(0)

if not camera.isOpened():
    print("Error")
    exit()


def node():
    rospy.init_node('camera_demo', anonymous=True)
    detection_pub = rospy.Publisher('/apriltag_detections', np.ndarray, queue_size=10)


if __name__ == '__main__':
    node()
